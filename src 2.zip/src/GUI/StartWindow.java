package GUI;

import Application.Controller.Controller;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StartWindow extends Application {

	
	@Override
	public void init() {
		Controller.initStorage();
	}

	@Override
	public void start(Stage stage) {
		stage.setTitle("KAS");

		BorderPane borderPane = new BorderPane();
		TabPane tabTilmelding = new TabPane();

		this.initContent(borderPane);

		Scene scene = new Scene(borderPane);
		stage.setScene(scene);
		stage.show();
	}

	// -------------------------------------------------------------------------

	private void initContent(BorderPane pane) {
		TilmeldTab tilmeldTab = new TilmeldTab();
		AdminTab adminTab = new AdminTab();

		TabPane tabTilmelding = new TabPane();

		Tab tab1 = new Tab("Tilmeding", new Label("Admin"));
		Tab tab2 = new Tab("Admin"  , new Label("Tilmeld"));

		tab1.setContent(tilmeldTab);
		tab2.setContent(adminTab);
		tabTilmelding.getTabs().add(tab1);
		tabTilmelding.getTabs().add(tab2);

		VBox vBox = new VBox(tabTilmelding);
		Scene scene = new Scene(vBox);


		pane.setCenter(tabTilmelding);
	}



}
