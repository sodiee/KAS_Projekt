package Application.Model;

public abstract class APerson {
    private String name;
    private String address;
    private String country;
    private int phoneNumber;

    public APerson(String name, String address, String country, int phoneNumber){
        this.name = name;
        this.address = address;
        this.country = country;
        this.phoneNumber = phoneNumber;
    }
}
