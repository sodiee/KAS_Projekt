package Application.Model;

public class Participant extends APerson {
    private String companyName;
    private int companyPhoneNumber;

    public Participant(String name, String address, String country, int phoneNumber) {
        super(name, address, country, phoneNumber);
    }
    public Participant(String name, String address, String country, int phoneNumber, String companyName, int companyPhoneNumber) {
        super(name, address, country, phoneNumber);
        this.companyName = companyName;
        this.companyPhoneNumber = companyPhoneNumber;
    }

    public void registerToConference(){}

}
