package Application.Model;

public class CompanionActivity {
    private String activityName;
    private String activityLocation;
    private int activityPrice;
    private String activityDuration;

    public CompanionActivity(String activityName, String activityLocation, int activityPrice, String activityDuration) {
        this.activityName = activityName;
        this.activityLocation = activityLocation;
        this.activityPrice = activityPrice;
        this.activityDuration = activityDuration;
    }
    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityLocation() {
        return activityLocation;
    }

    public void setActivityLocation(String activityLocation) {
        this.activityLocation = activityLocation;
    }

    public int getActivityPrice() {
        return activityPrice;
    }

    public void setActivityPrice(int activityPrice) {
        this.activityPrice = activityPrice;
    }

    public String getActivityDuration() {
        return activityDuration;
    }

    public void setActivityDuration(String activityDuration) {
        this.activityDuration = activityDuration;
    }
}
